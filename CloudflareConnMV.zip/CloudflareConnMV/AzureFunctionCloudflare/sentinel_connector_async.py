import datetime
import logging
import json
import hashlib
import hmac
import base64
import aiohttp
import asyncio
from collections import deque


class AzureSentinelConnectorAsync:
    def __init__(self, session: aiohttp.ClientSession, workspaces, log_type, queue_size=1000, queue_size_bytes=25 * (2**20)):
        """
        Initialize the AzureSentinelConnectorAsync with multiple workspaces.

        Args:
            session (aiohttp.ClientSession): HTTP session for making requests.
            workspaces (list): A list of dictionaries with keys 'log_analytics_uri', 'workspace_id', and 'shared_key'.
            log_type (str): Log type to send to Azure Sentinel.
            queue_size (int): Maximum number of logs in the queue.
            queue_size_bytes (int): Maximum size of the queue in bytes.
        """
        self.workspaces = workspaces
        self.log_type = log_type
        self.queue_size = queue_size
        self.queue_size_bytes = queue_size_bytes
        self._queue = deque()
        self.successful_sent_events_number = 0
        self.failed_sent_events_number = 0
        self.lock = asyncio.Lock()
        self.session = session

    async def _build_signature(self, workspace_id, shared_key, content_length, rfc1123date):
        string_to_hash = (f"POST\n{content_length}\napplication/json\nx-ms-date:{rfc1123date}\n/api/logs")
        bytes_to_hash = bytes(string_to_hash, encoding="utf-8")
        decoded_key = base64.b64decode(shared_key)
        encoded_hash = base64.b64encode(hmac.new(decoded_key, bytes_to_hash, hashlib.sha256).digest()).decode()
        return f"SharedKey {workspace_id}:{encoded_hash}"

    async def _send_to_workspace(self, log, workspace):
        """Send a log to a specific workspace."""
        workspace_id = workspace['workspace_id']
        shared_key = workspace['shared_key']
        log_analytics_uri = workspace['log_analytics_uri']

        body = json.dumps(log)
        content_length = len(body)
        rfc1123date = datetime.datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
        signature = await self._build_signature(workspace_id, shared_key, content_length, rfc1123date)

        uri = f"{log_analytics_uri}/api/logs?api-version=2016-04-01"
        headers = {
            "Content-Type": "application/json",
            "Authorization": signature,
            "Log-Type": self.log_type,
            "x-ms-date": rfc1123date,
        }

        async with self.session.post(uri, data=body, headers=headers) as response:
            if response.status in [200, 201]:
                self.successful_sent_events_number += 1
                logging.info(f"Successfully sent log to workspace {workspace_id}.")
            else:
                self.failed_sent_events_number += 1
                error_text = await response.text()
                logging.error(f"Failed to send log to workspace {workspace_id}: {response.status} {error_text}")

    async def send(self, log):
        """Send a log to all configured workspaces."""
        async with self.lock:
            self._queue.append(log)
            if len(self._queue) >= self.queue_size:
                events = list(self._queue)
                self._queue.clear()
                await asyncio.gather(*[
                    self._send_to_workspace(event, workspace)
                    for event in events
                    for workspace in self.workspaces
                ])
