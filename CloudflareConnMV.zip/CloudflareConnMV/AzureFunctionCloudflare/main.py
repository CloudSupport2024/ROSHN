import os
import asyncio
from azure.storage.blob.aio import ContainerClient
import json
import logging
import azure.functions as func
from json import JSONDecodeError
from .sentinel_connector_async import AzureSentinelConnectorAsync

# Reduce logging noise
logging.getLogger('azure.core.pipeline.policies.http_logging_policy').setLevel(logging.ERROR)
logging.getLogger('charset_normalizer').setLevel(logging.ERROR)

# Constants and Environment Variables
MAX_SCRIPT_EXEC_TIME_MINUTES = 5
AZURE_STORAGE_CONNECTION_STRING = os.environ['AZURE_STORAGE_CONNECTION_STRING']
CONTAINER_NAME = os.environ['CONTAINER_NAME']
WORKSPACE_ID_1 = os.environ['WORKSPACE_ID_1']
SHARED_KEY_1 = os.environ['SHARED_KEY_1']
WORKSPACE_ID_2 = os.environ['WORKSPACE_ID_2']
SHARED_KEY_2 = os.environ['SHARED_KEY_2']
LOG_TYPE = 'Cloudflare'
LINE_SEPARATOR = os.environ.get('lineSeparator', '[\n\r]+')
MAX_CONCURRENT_PROCESSING_FILES = int(os.environ.get('MAX_CONCURRENT_PROCESSING_FILES', '5'))

async def main_function(event: func.EventGridEvent):
    """Main function to process and send logs to two workspaces."""
    try:
        container_client = ContainerClient.from_connection_string(
            AZURE_STORAGE_CONNECTION_STRING, CONTAINER_NAME
        )

        async with aiohttp.ClientSession() as session:
            sentinel_1 = AzureSentinelConnectorAsync(
                session,
                os.environ['LOG_ANALYTICS_URI_1'],
                WORKSPACE_ID_1,
                SHARED_KEY_1,
                LOG_TYPE,
            )
            sentinel_2 = AzureSentinelConnectorAsync(
                session,
                os.environ['LOG_ANALYTICS_URI_2'],
                WORKSPACE_ID_2,
                SHARED_KEY_2,
                LOG_TYPE,
            )

            # Retrieve and process logs from Azure Blob Storage
            blob_name = event.subject
            blob_client = container_client.get_blob_client(blob_name)
            stream = await blob_client.download_blob()
            raw_data = await stream.readall()

            # Parse and send logs to both workspaces
            logs = json.loads(raw_data.decode("utf-8"))
            for log in logs:
                await asyncio.gather(
                    sentinel_1.send(log),
                    sentinel_2.send(log)
                )

            logging.info(f"Successfully sent logs for {blob_name} to both workspaces.")

    except Exception as e:
        logging.error(f"Failed to process event {event.id}: {str(e)}")
        traceback.print_exc()

# Azure Function entry point
def main(event: func.EventGridEvent):
    asyncio.run(main_function(event))